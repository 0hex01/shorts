#!/usr/bin/env python3
import os
import json
import stat
import subprocess
import logging
import traceback
import argparse
import sys

# Import GUI libraries
try:
    import customtkinter as ctk
    import tkinter as tk
    from tkinter import messagebox
    HAS_GUI = True
except ImportError:
    HAS_GUI = False

# Set up logging
log_dir = '/var/log/shorts'
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'shorts.log')

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ]
)

import sys
import traceback
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk

class ShortcutError(Exception):
    """Base exception class for shortcut manager errors"""
    pass

class ConfigError(ShortcutError):
    """Error in configuration or settings"""
    pass

class ExecutionError(ShortcutError):
    """Error executing a shortcut"""
    pass

class PermissionError(ShortcutError):
    """Error related to file or system permissions"""
    pass

def handle_error(func):
    """Decorator for handling errors in GUI and CLI modes"""
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ShortcutError as e:
            error_msg = str(e)
            logging.error(f"Shortcut error in {func.__name__}: {error_msg}")
            if hasattr(args[0], 'gui') and args[0].gui:
                messagebox.showerror("Error", error_msg)
            else:
                print(f"Error: {error_msg}", file=sys.stderr)
        except Exception as e:
            error_msg = f"Unexpected error in {func.__name__}: {str(e)}"
            logging.error(f"{error_msg}\n{traceback.format_exc()}")
            if hasattr(args[0], 'gui') and args[0].gui:
                messagebox.showerror("Error", error_msg)
            else:
                print(f"Error: {error_msg}", file=sys.stderr)
                print("Full traceback:", file=sys.stderr)
                traceback.print_exc(file=sys.stderr)
    return wrapper

class ShortcutManager(ctk.CTk if HAS_GUI else object):
    def __init__(self, gui=True):
        try:
            self.gui = gui
            if gui and not HAS_GUI:
                raise ConfigError("GUI libraries not available")

            # Initialize GUI if needed
            if gui:
                super().__init__()

            # Get the real user's home directory
            real_user = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
            if real_user == 'root' and os.getenv('SUDO_USER'):
                real_user = os.getenv('SUDO_USER')
                self.shortcuts_file = os.path.join('/home', real_user, '.shortcuts.json')
            else:
                self.shortcuts_file = os.path.expanduser('~/.shortcuts.json')

            # Initialize shortcuts data
            self.shortcuts = {}
            self.import_existing_scripts()

            # Initialize GUI components if needed
            if gui:
                # Configure the window
                self.title("Shortcut Manager")
                self.geometry("600x500")
                ctk.set_appearance_mode("dark")
                ctk.set_default_color_theme("dark-blue")

                # Set window icon
                try:
                    icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets', 'icon.png')
                    if os.path.exists(icon_path):
                        self.iconphoto(True, tk.PhotoImage(file=icon_path))
                except Exception as e:
                    logging.warning(f"Failed to set window icon: {str(e)}")

                # Create main frame
                self.main_frame = ctk.CTkFrame(self)
                self.main_frame.pack(padx=10, pady=10, fill="both", expand=True)

                # Initialize editing state
                self.editing_shortcut = None

                # Create widgets
                self.create_widgets()
        except Exception as e:
            logging.error(f"Failed to initialize ShortcutManager: {str(e)}\n{traceback.format_exc()}")
            if gui:
                messagebox.showerror("Error", f"Failed to initialize application: {str(e)}")
            raise

    def _init_gui(self):
        """Initialize the GUI components"""
        # Configure the window
        self.title("Shortcut Manager")
        self.geometry("600x500")
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        # Set window icon
        try:
            icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets', 'icon.png')
            if os.path.exists(icon_path):
                self.iconphoto(True, tk.PhotoImage(file=icon_path))
        except Exception as e:
            logging.warning(f"Failed to set window icon: {str(e)}")

        # Create main frame
        self.main_frame = ctk.CTkFrame(self)
        self.main_frame.pack(padx=10, pady=10, fill="both", expand=True)

        # Initialize editing state
        self.editing_shortcut = None

        # Create widgets
        self.create_widgets()



    def create_widgets(self):
        # Input frame
        self.input_frame = ctk.CTkFrame(self.main_frame)
        self.input_frame.pack(padx=5, pady=5, fill="x")

        # Shortcut name entry
        self.name_label = ctk.CTkLabel(self.input_frame, text="Shortcut Name:")
        self.name_label.pack(padx=5, pady=5, anchor="w")
        self.name_entry = ctk.CTkEntry(self.input_frame, width=300)
        self.name_entry.pack(padx=5, pady=5, anchor="w")

        # Command entry
        self.command_label = ctk.CTkLabel(self.input_frame, text="Command:")
        self.command_label.pack(padx=5, pady=5, anchor="w")
        self.command_entry = ctk.CTkEntry(self.input_frame, width=300)
        self.command_entry.pack(padx=5, pady=5, anchor="w")

        # Background checkbox
        self.background_var = ctk.BooleanVar()
        self.background_check = ctk.CTkCheckBox(self.input_frame, text="Run in background",
                                              variable=self.background_var)
        self.background_check.pack(padx=5, pady=5, anchor="w")

        # Passwordless sudo checkbox
        self.sudo_var = ctk.BooleanVar()
        self.sudo_check = ctk.CTkCheckBox(self.input_frame, text="Enable passwordless sudo",
                                        variable=self.sudo_var)
        self.sudo_check.pack(padx=5, pady=5, anchor="w")

        # Buttons frame
        self.buttons_frame = ctk.CTkFrame(self.input_frame)
        self.buttons_frame.pack(padx=5, pady=5, fill="x")

        # Add/Save button
        self.action_button = ctk.CTkButton(self.buttons_frame, text="Add Shortcut",
                                         command=self.add_or_update_shortcut)
        self.action_button.pack(side="left", padx=5)

        # Cancel button (hidden by default)
        self.cancel_button = ctk.CTkButton(self.buttons_frame, text="Cancel",
                                         command=self.cancel_edit)
        
        # Shortcuts list
        self.shortcuts_frame = ctk.CTkFrame(self.main_frame)
        self.shortcuts_frame.pack(padx=5, pady=5, fill="both", expand=True)

    def import_existing_scripts(self):
        try:
            # First load saved shortcuts
            if os.path.exists(self.shortcuts_file):
                try:
                    with open(self.shortcuts_file, 'r') as f:
                        self.shortcuts = json.load(f)
                    logging.info(f'Loaded {len(self.shortcuts)} shortcuts from {self.shortcuts_file}')
                except Exception as e:
                    logging.error(f'Failed to load shortcuts file: {str(e)}')
                    self.shortcuts = {}
            else:
                logging.info('No existing shortcuts file found')
                self.shortcuts = {}
            
            logging.info('Starting import of existing scripts')
            bin_dir = "/usr/local/bin"
            if not os.path.exists(bin_dir):
                logging.warning(f'Directory not found: {bin_dir}')
                return

            for file in os.listdir(bin_dir):
                try:
                    # Skip the shorts launcher itself
                    if file == 'shorts':
                        continue

                    file_path = os.path.join(bin_dir, file)
                    if os.path.isfile(file_path) and os.access(file_path, os.X_OK):
                        try:
                            with open(file_path, 'r', encoding='utf-8') as f:
                                content = f.read()
                                if '#!/bin/bash' in content:
                                    # Extract command from script
                                    lines = [line.strip() for line in content.split('\n') 
                                            if line.strip() and not line.startswith('#')]
                                    
                                    # Find the main command line
                                    cmd = None
                                    is_background = False

                                    # For windy, specifically look for the windsurf command
                                    if file == 'windy':
                                        for line in lines:
                                            if 'windsurf' in line:
                                                cmd = line
                                                is_background = True
                                                break
                                    else:
                                        # For other scripts, take the first real command
                                        for line in lines:
                                            if not line.startswith('cd ') and not line.startswith('source ') \
                                               and line not in ['then', 'fi', 'else', 'do', 'done']:
                                                cmd = line
                                                break

                                    if cmd:
                                        # Split on common command separators and take first command
                                        for separator in [' && ', ' ; ', ' || ']:
                                            if separator in cmd:
                                                cmd = cmd.split(separator)[0]

                                        # Remove background-related parts
                                        for remove in ['nohup', '>/dev/null', '2>&1', '&']:
                                            cmd = cmd.replace(remove, '')

                                        # Remove sudo if present
                                        while 'sudo' in cmd:
                                            cmd = cmd.replace('sudo', '', 1)

                                        cmd = cmd.strip()
                                        if cmd:
                                            self.shortcuts[file] = {
                                                'command': cmd,
                                                'background': is_background
                                            }
                        except UnicodeDecodeError:
                            # Skip binary files
                            logging.debug(f'Skipping binary file: {file_path}')
                            continue
                except Exception as e:
                    self.log_error(f'Error importing {file}', e)
        except Exception as e:
            self.log_error("Error during script import", e)

    def load_shortcuts(self):
        if os.path.exists(self.shortcuts_file):
            with open(self.shortcuts_file, 'r') as f:
                return json.load(f)
        return {}

    def handle_exception(self, exc_type, exc_value, exc_traceback):
        """Handle uncaught exceptions"""
        error_msg = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logging.error(f'Uncaught exception:\n{error_msg}')
        messagebox.showerror('Error', f'An unexpected error occurred. Check {log_file} for details.')

    def log_error(self, message, error):
        """Log error with traceback and show user-friendly message"""
        logging.error(f'{message}:\n{traceback.format_exc()}')
        messagebox.showerror('Error', f'{message}\n{str(error)}\nCheck {log_file} for details.')

    def save_shortcuts(self):
        try:
            logging.debug('Saving shortcuts to file')
            # Ensure parent directory exists and has correct permissions
            shortcuts_dir = os.path.dirname(self.shortcuts_file)
            os.makedirs(shortcuts_dir, exist_ok=True)
            
            # Get the real user's UID/GID
            real_user = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
            if real_user != 'root':
                import pwd
                uid = pwd.getpwnam(real_user).pw_uid
                gid = pwd.getpwnam(real_user).pw_gid
                # Set directory ownership
                os.chown(shortcuts_dir, uid, gid)
                os.chmod(shortcuts_dir, 0o755)  # rwxr-xr-x
            
            # Save shortcuts
            with open(self.shortcuts_file, 'w') as f:
                json.dump(self.shortcuts, f, indent=4)
            
            # Set file ownership and permissions
            if real_user != 'root':
                os.chown(self.shortcuts_file, uid, gid)
            os.chmod(self.shortcuts_file, 0o644)  # rw-r--r--
            
            logging.info('Shortcuts saved successfully')
        except Exception as e:
            self.log_error('Error saving shortcuts', e)

    def create_shortcut_script(self, name, command, background):
        script_path = f"/usr/local/bin/{name}"
        
        script_content = "#!/bin/bash\n\n"
        
        # Add sudo to the command
        if background:
            script_content += f"sudo nohup {command} >/dev/null 2>&1 &\n"
        else:
            script_content += f"sudo {command}\n"

        try:
            with open(script_path, 'w') as f:
                f.write(script_content)

            # Make the script owned by root and executable by all
            os.chown(script_path, 0, 0)  # root:root
            os.chmod(script_path, 0o755)  # rwxr-xr-x

            # Add to sudoers if requested
            if self.sudo_var.get():
                self.add_to_sudoers(name)
            
            return True
        except PermissionError:
            messagebox.showerror("Error", "Permission denied. Try running with sudo.")
            return False
        except Exception as e:
            if gui:
                messagebox.showerror("Error", f"Failed to create shortcut: {str(e)}")
            else:
                print(f"Error: Failed to create shortcut: {str(e)}")
            return False

    def add_to_sudoers(self, name):
        try:
            # Create a new sudoers file for the shortcut
            sudoers_path = f"/etc/sudoers.d/{name}"
            username = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
            
            # Create the sudoers entry
            sudoers_content = f"{username} ALL=(ALL) NOPASSWD: /usr/local/bin/{name}\n"
            
            # Write to a temporary file first
            temp_path = f"/tmp/{name}.sudoers"
            with open(temp_path, 'w') as f:
                f.write(sudoers_content)
            
            # Use visudo to safely install the file
            result = subprocess.run(['sudo', 'visudo', '-c', '-f', temp_path], capture_output=True, text=True)
            if result.returncode == 0:
                subprocess.run(['sudo', 'mv', temp_path, sudoers_path])
                subprocess.run(['sudo', 'chmod', '0440', sudoers_path])
            else:
                os.unlink(temp_path)
                if hasattr(self, 'gui') and self.gui:
                    messagebox.showerror("Error", f"Invalid sudoers entry: {result.stderr}")
                else:
                    print(f"Error: Invalid sudoers entry: {result.stderr}")
        except Exception as e:
            if hasattr(self, 'gui') and self.gui:
                messagebox.showerror("Error", f"Failed to configure sudoers: {str(e)}")
            else:
                print(f"Error: Failed to configure sudoers: {str(e)}")

    def add_or_update_shortcut(self):
        name = self.name_entry.get().strip()
        command = self.command_entry.get().strip()
        background = self.background_var.get()
        passwordless = self.sudo_var.get()

        if not name or not command:
            messagebox.showerror("Error", "Name and command are required!")
            return

        if not name.isalnum() and not '_' in name:
            messagebox.showerror("Error", "Name must be alphanumeric (underscores allowed)")
            return

        if hasattr(self, 'old_shortcut_name') and self.old_shortcut_name != name:
            # Delete old shortcut if name changed
            self.delete_shortcut(self.old_shortcut_name, update_ui=False)

        if self.create_shortcut_script(name, command, background):
            self.shortcuts[name] = {
                'command': command,
                'background': background,
                'passwordless': passwordless
            }
            self.save_shortcuts()
            self.update_shortcuts_list()
            self.clear_form()

    def clear_form(self):
        self.name_entry.delete(0, 'end')
        self.command_entry.delete(0, 'end')
        self.background_var.set(False)
        self.action_button.configure(text="Add Shortcut")
        self.cancel_button.pack_forget()
        self.editing_shortcut = None
        if hasattr(self, 'old_shortcut_name'):
            del self.old_shortcut_name

    def cancel_edit(self):
        self.clear_form()

    def edit_shortcut(self, name):
        if name in self.shortcuts:
            self.editing_shortcut = name
            data = self.shortcuts[name]
            
            self.name_entry.delete(0, 'end')
            self.name_entry.insert(0, name)
            
            self.command_entry.delete(0, 'end')
            self.command_entry.insert(0, data['command'])
            
            self.background_var.set(data.get('background', False))
            self.sudo_var.set(data.get('passwordless', False))
            
            self.action_button.configure(text="Save Changes")
            self.cancel_button.pack(side="left", padx=5)
            
            # Save the old name for deletion if name changes
            self.old_shortcut_name = name

    def delete_shortcut(self, name, update_ui=True):
        if name in self.shortcuts:
            script_path = f"/usr/local/bin/{name}"
            sudoers_path = f"/etc/sudoers.d/{name}"
            try:
                # Remove the script
                os.remove(script_path)
                
                # Remove sudoers file if it exists
                if os.path.exists(sudoers_path):
                    subprocess.run(['sudo', 'rm', '-f', sudoers_path])
                
                del self.shortcuts[name]
                self.save_shortcuts()
                if update_ui:
                    self.update_shortcuts_list()
            except PermissionError:
                messagebox.showerror("Error", "Permission denied. Try running with sudo.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete shortcut: {str(e)}")

    def update_shortcuts_list(self):
        # Clear existing shortcuts
        for widget in self.shortcuts_frame.winfo_children():
            widget.destroy()

        # Header
        header = ctk.CTkLabel(self.shortcuts_frame, text="Existing Shortcuts:",
                            font=("Arial", 14, "bold"))
        header.pack(padx=5, pady=5, anchor="w")

        # Add each shortcut
        for name, data in self.shortcuts.items():
            shortcut_frame = ctk.CTkFrame(self.shortcuts_frame)
            shortcut_frame.pack(padx=5, pady=2, fill="x")

            label_text = f"{name}: {data['command']}"
            if data['background']:
                label_text += " (background)"

            label = ctk.CTkLabel(shortcut_frame, text=label_text)
            label.pack(side="left", padx=5)

            # Button frame
            btn_frame = ctk.CTkFrame(shortcut_frame)
            btn_frame.pack(side="right", padx=5)

            edit_btn = ctk.CTkButton(btn_frame, text="Edit",
                                   command=lambda n=name: self.edit_shortcut(n),
                                   width=60)
            edit_btn.pack(side="left", padx=2)

            delete_btn = ctk.CTkButton(btn_frame, text="Delete",
                                     command=lambda n=name: self.delete_shortcut(n),
                                     width=60)
            delete_btn.pack(side="left", padx=2)

def parse_arguments():
    parser = argparse.ArgumentParser(
        description='Shorts - A command line tool for managing system shortcuts',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Description:
  Shorts is a tool for creating and managing system-wide command shortcuts.
  When run without arguments, it opens a graphical interface for managing shortcuts.
  Shortcuts can be run in the background, and with optional passwordless sudo access.

Examples:
  # Launch GUI (no arguments)
  %(prog)s

  # List all shortcuts
  %(prog)s -l
  %(prog)s --list

  # Create a new shortcut
  %(prog)s -c myshort -m "command to run"      # Basic shortcut
  %(prog)s --create backup --command "rsync -av /src /dst"  # Backup shortcut

  # Create shortcut with special options
  %(prog)s -c server -m "python app.py" -b     # Run in background
  %(prog)s -c update -m "apt update" -p        # Run with sudo, no password
  %(prog)s -c docker -m "docker-compose up" -b -p  # Background + sudo

  # Delete a shortcut
  %(prog)s -d myshort
  %(prog)s --delete myshort

  # Search for shortcuts
  %(prog)s -s backup     # Find backup-related shortcuts
  %(prog)s --search net  # Find network-related shortcuts

Notes:
  - Shortcuts are stored in ~/.shortcuts.json
  - Scripts are created in /usr/local/bin
  - Background shortcuts run with nohup
  - Passwordless shortcuts are added to sudoers.d
'''
    )
    
    parser.add_argument(
        '-l', '--list',
        action='store_true',
        help='List all available shortcuts with their commands'
    )
    parser.add_argument(
        '-c', '--create',
        metavar='NAME',
        help='Create a new shortcut with the specified name (alphanumeric + underscores)'
    )
    parser.add_argument(
        '-m', '--command',
        metavar='COMMAND',
        help='Shell command to execute when the shortcut is run (use quotes for multi-word commands)'
    )
    parser.add_argument(
        '-b', '--background',
        action='store_true',
        help='Run the shortcut in the background (using nohup)'
    )
    parser.add_argument(
        '-p', '--passwordless',
        action='store_true',
        help='Allow the shortcut to run with sudo without requiring a password (adds to sudoers.d)'
    )
    parser.add_argument(
        '-d', '--delete',
        metavar='NAME',
        help='Delete the specified shortcut'
    )
    parser.add_argument(
        '-s', '--search',
        metavar='KEYWORD',
        help='Search for shortcuts containing the keyword'
    )
    
    return parser.parse_args()

@handle_error
def cli_list_shortcuts():
    manager = ShortcutManager(gui=False)
    shortcuts = manager.shortcuts
    if not shortcuts:
        print("No shortcuts found.")
        return
    
    print("Available shortcuts:")
    for name, data in shortcuts.items():
        print(f"  {name}: {data['command']}" + (" (background)" if data['background'] else ""))

@handle_error
def cli_create_shortcut(name, command, background=False, passwordless=False):
    if not name or not command:
        raise ConfigError("Name and command are required")
    
    if not name.isalnum() and not '_' in name:
        raise ConfigError("Name must be alphanumeric (underscores allowed)")
    
    manager = ShortcutManager(gui=False)
    manager.sudo_var = type('obj', (object,), {'get': lambda: passwordless})
    
    try:
        if manager.create_shortcut_script(name, command, background):
            manager.shortcuts[name] = {
                'command': command,
                'background': background
            }
            manager.save_shortcuts()
            print(f"Shortcut '{name}' created successfully.")
            return 0
        raise ExecutionError("Failed to create shortcut script")
    except Exception as e:
        raise ExecutionError(f"Failed to create shortcut: {str(e)}")

@handle_error
def cli_delete_shortcut(name):
    if not name:
        raise ConfigError("Name is required")
    
    manager = ShortcutManager(gui=False)
    if name not in manager.shortcuts:
        raise ConfigError(f"Shortcut '{name}' not found")
    
    try:
        manager.delete_shortcut(name)
        print(f"Shortcut '{name}' deleted successfully.")
        return 0
    except Exception as e:
        raise ExecutionError(f"Failed to delete shortcut: {str(e)}")

@handle_error
def cli_search_shortcuts(keyword):
    if not keyword:
        raise ConfigError("Search keyword is required")
    
    manager = ShortcutManager(gui=False)
    found = False
    for name, data in manager.shortcuts.items():
        if keyword.lower() in name.lower() or keyword.lower() in data['command'].lower():
            if not found:
                print("Matching shortcuts:")
                found = True
            print(f"  {name}: {data['command']}" + (" (background)" if data['background'] else ""))
    
    if not found:
        print("No matching shortcuts found.")
    return 0

def main():
    try:
        # If no arguments, launch GUI
        if len(sys.argv) == 1:
            app = ShortcutManager(gui=True)
            app.mainloop()
            return
        
        # Parse command line arguments
        args = parse_arguments()
        
        if args.list:
            cli_list_shortcuts()
        elif args.create:
            if not args.command:
                raise ConfigError("Command is required when creating a shortcut")
            sys.exit(cli_create_shortcut(args.create, args.command, args.background, args.passwordless))
        elif args.delete:
            sys.exit(cli_delete_shortcut(args.delete))
        elif args.search:
            sys.exit(cli_search_shortcuts(args.search))
        else:
            print("Invalid command. Use -h or --help for usage information.")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        logging.error(f"Unhandled error in main: {str(e)}\n{traceback.format_exc()}")
        sys.exit(1)

if __name__ == "__main__":
    main()
