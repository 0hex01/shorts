#!/usr/bin/env python3
import os
import sys

# Add our bundled distutils to the Python path
lib_path = os.path.join(os.path.dirname(__file__), 'lib', 'python3')
if os.path.exists(lib_path):
    sys.path.insert(0, lib_path)

import json
import stat
import subprocess
import logging
import traceback
import argparse
import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox

# Set up logging
log_dir = '/var/log/shorts'
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, 'shorts.log')

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file),
        logging.StreamHandler()
    ]
)

class ShortcutManager(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Configure the window
        self.title("Shortcut Manager")
        self.geometry("600x500")
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        # Set window icon
        try:
            icon_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'assets', 'icon.png')
            if os.path.exists(icon_path):
                self.iconphoto(True, tk.PhotoImage(file=icon_path))
        except Exception as e:
            print(f"Error setting icon: {str(e)}")

        # Initialize shortcuts data
        # Use the real user's home directory, not root's
        real_user = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
        if real_user == 'root' and os.getenv('SUDO_USER'):
            real_user = os.getenv('SUDO_USER')
            self.shortcuts_file = os.path.join('/home', real_user, '.shortcuts.json')
        else:
            self.shortcuts_file = os.path.expanduser('~/.shortcuts.json')
        self.shortcuts = self.load_shortcuts()

        # Create main frame
        self.main_frame = ctk.CTkFrame(self)
        self.main_frame.pack(padx=10, pady=10, fill="both", expand=True)

        # Initialize editing state
        self.editing_shortcut = None

        # Import existing scripts
        self.import_existing_scripts()

        # Create widgets
        self.create_widgets()

        # Create shortcuts list
        self.update_shortcuts_list()

    def create_widgets(self):
        # Input frame
        self.input_frame = ctk.CTkFrame(self.main_frame)
        self.input_frame.pack(padx=5, pady=5, fill="x")

        # Shortcut name entry
        self.name_label = ctk.CTkLabel(self.input_frame, text="Shortcut Name:")
        self.name_label.pack(padx=5, pady=5, anchor="w")
        self.name_entry = ctk.CTkEntry(self.input_frame, width=300)
        self.name_entry.pack(padx=5, pady=5, anchor="w")

        # Command entry
        self.command_label = ctk.CTkLabel(self.input_frame, text="Command:")
        self.command_label.pack(padx=5, pady=5, anchor="w")
        self.command_entry = ctk.CTkEntry(self.input_frame, width=300)
        self.command_entry.pack(padx=5, pady=5, anchor="w")

        # Background checkbox
        self.background_var = ctk.BooleanVar()
        self.background_check = ctk.CTkCheckBox(self.input_frame, text="Run in background",
                                              variable=self.background_var)
        self.background_check.pack(padx=5, pady=5, anchor="w")

        # Passwordless sudo checkbox
        self.sudo_var = ctk.BooleanVar()
        self.sudo_check = ctk.CTkCheckBox(self.input_frame, text="Enable passwordless sudo",
                                        variable=self.sudo_var)
        self.sudo_check.pack(padx=5, pady=5, anchor="w")

        # Buttons frame
        self.buttons_frame = ctk.CTkFrame(self.input_frame)
        self.buttons_frame.pack(padx=5, pady=5, fill="x")

        # Add/Save button
        self.action_button = ctk.CTkButton(self.buttons_frame, text="Add Shortcut",
                                         command=self.add_or_update_shortcut)
        self.action_button.pack(side="left", padx=5)

        # Cancel button (hidden by default)
        self.cancel_button = ctk.CTkButton(self.buttons_frame, text="Cancel",
                                         command=self.cancel_edit)
        
        # Create scrollable frame for shortcuts list
        self.shortcuts_frame = ctk.CTkScrollableFrame(self.main_frame)
        self.shortcuts_frame.pack(padx=5, pady=5, fill="both", expand=True)

    def import_existing_scripts(self):
        try:
            bin_dir = "/usr/local/bin"
            if not os.path.exists(bin_dir):
                logging.warning(f'Directory not found: {bin_dir}')
                return
            
            logging.info('Starting import of existing scripts')
            for file in os.listdir(bin_dir):
                try:
                    # Skip the shorts launcher itself
                    if file == 'shorts':
                        continue

                    file_path = os.path.join(bin_dir, file)
                    if os.path.isfile(file_path) and os.access(file_path, os.X_OK):
                        try:
                            with open(file_path, 'r', encoding='utf-8') as f:
                                content = f.read()
                                if '#!/bin/bash' in content:
                                    # Extract command from script
                                    lines = [line.strip() for line in content.split('\n') 
                                            if line.strip() and not line.startswith('#')]
                                    
                                    # Find the main command line
                                    cmd = None
                                    is_background = False

                                    # For windy, specifically look for the windsurf command
                                    if file == 'windy':
                                        for line in lines:
                                            if 'windsurf' in line:
                                                cmd = line
                                                is_background = True
                                                break
                                    else:
                                        # For other scripts, take the first real command
                                        for line in lines:
                                            if not line.startswith('cd ') and not line.startswith('source ') \
                                               and line not in ['then', 'fi', 'else', 'do', 'done']:
                                                cmd = line
                                                break

                                    if cmd:
                                        # Split on common command separators and take first command
                                        for separator in [' && ', ' ; ', ' || ']:
                                            if separator in cmd:
                                                cmd = cmd.split(separator)[0]

                                        # Remove background-related parts
                                        for remove in ['nohup', '>/dev/null', '2>&1', '&']:
                                            cmd = cmd.replace(remove, '')

                                        # Remove sudo if present
                                        while 'sudo' in cmd:
                                            cmd = cmd.replace('sudo', '', 1)

                                        cmd = cmd.strip()
                                        if cmd:
                                            self.shortcuts[file] = {
                                                'command': cmd,
                                                'background': is_background
                                            }
                        except UnicodeDecodeError:
                            # Skip binary files
                            logging.debug(f'Skipping binary file: {file_path}')
                            continue
                except Exception as e:
                    self.log_error(f'Error importing {file}', e)
        except Exception as e:
            self.log_error("Error during script import", e)

    def load_shortcuts(self):
        if os.path.exists(self.shortcuts_file):
            with open(self.shortcuts_file, 'r') as f:
                return json.load(f)
        return {}

    def handle_exception(self, exc_type, exc_value, exc_traceback):
        """Handle uncaught exceptions"""
        error_msg = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logging.error(f'Uncaught exception:\n{error_msg}')
        messagebox.showerror('Error', f'An unexpected error occurred. Check {log_file} for details.')

    def log_error(self, message, error):
        """Log error with traceback and show user-friendly message"""
        logging.error(f'{message}:\n{traceback.format_exc()}')
        messagebox.showerror('Error', f'{message}\n{str(error)}\nCheck {log_file} for details.')

    def save_shortcuts(self):
        try:
            logging.debug('Saving shortcuts to file')
            os.makedirs(os.path.dirname(self.shortcuts_file), exist_ok=True)
            with open(self.shortcuts_file, 'w') as f:
                json.dump(self.shortcuts, f, indent=4)
            
            real_user = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
            if real_user != 'root':
                import pwd
                uid = pwd.getpwnam(real_user).pw_uid
                gid = pwd.getpwnam(real_user).pw_gid
                os.chown(self.shortcuts_file, uid, gid)
            logging.info('Shortcuts saved successfully')
        except Exception as e:
            self.log_error('Error saving shortcuts', e)

    def create_shortcut_script(self, name, command, background):
        script_path = f"/usr/local/bin/{name}"
        
        script_content = "#!/bin/bash\n\n"
        
        # Add sudo to the command
        if background:
            script_content += f"sudo nohup {command} >/dev/null 2>&1 &\n"
        else:
            script_content += f"sudo {command}\n"

        try:
            with open(script_path, 'w') as f:
                f.write(script_content)

            # Make the script executable
            st = os.stat(script_path)
            os.chmod(script_path, st.st_mode | stat.S_IEXEC)

            # Add to sudoers if requested
            if self.sudo_var.get():
                self.add_to_sudoers(name)
            
            return True
        except PermissionError:
            messagebox.showerror("Error", "Permission denied. Try running with sudo.")
            return False
        except Exception as e:
            messagebox.showerror("Error", f"Failed to create shortcut: {str(e)}")
            return False

    def add_to_sudoers(self, name):
        try:
            # Create a new sudoers file for the shortcut
            sudoers_path = f"/etc/sudoers.d/{name}"
            username = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
            
            # Create the sudoers entry
            sudoers_content = f"{username} ALL=(ALL) NOPASSWD: /usr/local/bin/{name}\n"
            
            # Write to a temporary file first
            temp_path = f"/tmp/{name}.sudoers"
            with open(temp_path, 'w') as f:
                f.write(sudoers_content)
            
            # Use visudo to safely install the file
            result = subprocess.run(['sudo', 'visudo', '-c', '-f', temp_path], capture_output=True, text=True)
            if result.returncode == 0:
                subprocess.run(['sudo', 'mv', temp_path, sudoers_path])
                subprocess.run(['sudo', 'chmod', '0440', sudoers_path])
            else:
                os.unlink(temp_path)
                messagebox.showerror("Error", f"Invalid sudoers entry: {result.stderr}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to configure sudoers: {str(e)}")

    def add_or_update_shortcut(self):
        name = self.name_entry.get().strip()
        command = self.command_entry.get().strip()
        background = self.background_var.get()

        if not name or not command:
            messagebox.showerror("Error", "Name and command are required!")
            return

        if not name.isalnum() and not '_' in name:
            messagebox.showerror("Error", "Name must be alphanumeric (underscores allowed)")
            return

        if hasattr(self, 'old_shortcut_name') and self.old_shortcut_name != name:
            # Delete old shortcut if name changed
            self.delete_shortcut(self.old_shortcut_name, update_ui=False)

        if self.create_shortcut_script(name, command, background):
            self.shortcuts[name] = {
                'command': command,
                'background': background
            }
            self.save_shortcuts()
            self.update_shortcuts_list()
            self.clear_form()

    def clear_form(self):
        self.name_entry.delete(0, 'end')
        self.command_entry.delete(0, 'end')
        self.background_var.set(False)
        self.action_button.configure(text="Add Shortcut")
        self.cancel_button.pack_forget()
        self.editing_shortcut = None
        if hasattr(self, 'old_shortcut_name'):
            del self.old_shortcut_name

    def cancel_edit(self):
        self.clear_form()

    def edit_shortcut(self, name):
        if name in self.shortcuts:
            self.editing_shortcut = name
            data = self.shortcuts[name]
            
            self.name_entry.delete(0, 'end')
            self.name_entry.insert(0, name)
            
            self.command_entry.delete(0, 'end')
            self.command_entry.insert(0, data['command'])
            
            self.background_var.set(data['background'])
            
            self.action_button.configure(text="Save Changes")
            self.cancel_button.pack(side="left", padx=5)
            
            # Save the old name for deletion if name changes
            self.old_shortcut_name = name

    def delete_shortcut(self, name, update_ui=True):
        if name in self.shortcuts:
            script_path = f"/usr/local/bin/{name}"
            sudoers_path = f"/etc/sudoers.d/{name}"
            try:
                # Remove the script
                os.remove(script_path)
                
                # Remove sudoers file if it exists
                if os.path.exists(sudoers_path):
                    subprocess.run(['sudo', 'rm', '-f', sudoers_path])
                
                del self.shortcuts[name]
                self.save_shortcuts()
                if update_ui:
                    self.update_shortcuts_list()
            except PermissionError:
                messagebox.showerror("Error", "Permission denied. Try running with sudo.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete shortcut: {str(e)}")

    def update_shortcuts_list(self):
        # Clear existing shortcuts
        for widget in self.shortcuts_frame.winfo_children():
            widget.destroy()

        # Header
        header = ctk.CTkLabel(self.shortcuts_frame, text="Existing Shortcuts:",
                            font=("Arial", 14, "bold"))
        header.pack(padx=5, pady=5, anchor="w")

        # Add each shortcut
        for name, data in self.shortcuts.items():
            shortcut_frame = ctk.CTkFrame(self.shortcuts_frame)
            shortcut_frame.pack(padx=5, pady=2, fill="x")

            label_text = f"{name}: {data['command']}"
            if data['background']:
                label_text += " (background)"

            label = ctk.CTkLabel(shortcut_frame, text=label_text)
            label.pack(side="left", padx=5)

            # Button frame
            btn_frame = ctk.CTkFrame(shortcut_frame)
            btn_frame.pack(side="right", padx=5)

            edit_btn = ctk.CTkButton(btn_frame, text="Edit",
                                   command=lambda n=name: self.edit_shortcut(n),
                                   width=60)
            edit_btn.pack(side="left", padx=2)

            delete_btn = ctk.CTkButton(btn_frame, text="Delete",
                                     command=lambda n=name: self.delete_shortcut(n),
                                     width=60)
            delete_btn.pack(side="left", padx=2)

def list_shortcuts(shortcuts_file):
    """List all available shortcuts"""
    if os.path.exists(shortcuts_file):
        with open(shortcuts_file, 'r') as f:
            shortcuts = json.load(f)
            if not shortcuts:
                print("No shortcuts found.")
                return
            print("Available shortcuts:")
            for name, data in shortcuts.items():
                bg = " (runs in background)" if data['background'] else ""
                print(f"  {name}: {data['command']}{bg}")
    else:
        print("No shortcuts found.")

def print_usage_examples():
    """Print usage examples for the shorts command"""
    examples = """
Usage Examples:
  1. Launch GUI:
    $ shorts

  2. List all shortcuts:
    $ shorts --list

  3. Quick shortcut creation:
    $ shorts 'shortcut-name' 'command1 -flag1 ; command2 -flag2'

  4. Add a new shortcut with flags:
    $ shorts --add --name="shortcut-name" --cmd="command" [--background]

  5. Show this help:
    $ shorts --help

Practical Examples:
  1. System update shortcut:
    $ shorts 'update-sys' 'apt update ; apt upgrade -y ; apt autoremove -y'

  2. Network service restart:
    $ shorts 'net-restart' 'systemctl restart NetworkManager ; service networking restart'

  3. Multiple sudo commands:
    $ shorts 'fix-dns' 'sudo rm /etc/resolv.conf ; sudo ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf'

  4. Background service with logging:
    $ shorts 'start-vpn' 'openvpn --config /etc/openvpn/client.ovpn > /var/log/vpn.log 2>&1' --background

  5. Development environment setup:
    $ shorts 'dev-env' 'docker-compose up -d ; npm install ; npm run dev'

  6. System maintenance:
    $ shorts 'maintain' 'bleachbit -c --preset ; timeshift --create'

Notes:
  - Use quotes around commands with spaces or special characters
  - Separate multiple commands with semicolons
  - Add --background for long-running or service-type commands
  - Shortcuts are stored in ~/.shortcuts.json
  - Scripts are created in /usr/local/bin/
    """
    print(examples)

def main():
    parser = argparse.ArgumentParser(
        description="Shortcut Manager - Create and manage system shortcuts",
        epilog="Run without arguments to launch the GUI")
    
    # Positional arguments for quick shortcut creation
    parser.add_argument('shortcut_name', nargs='?',
                        help='Shortcut name for quick creation')
    parser.add_argument('command', nargs='?',
                        help='Command for quick creation')
    
    # Optional arguments
    parser.add_argument('--list', '-l', action='store_true',
                        help='List all available shortcuts')
    parser.add_argument('--add', '-a', action='store_true',
                        help='Add a new shortcut')
    parser.add_argument('--name', '-n',
                        help='Name for the new shortcut (with --add)')
    parser.add_argument('--cmd', '-c',
                        help='Command for the new shortcut (with --add)')
    parser.add_argument('--background', '-b', action='store_true',
                        help='Run the command in background')
    parser.add_argument('--examples', '-e', action='store_true',
                        help='Show usage examples')

    args = parser.parse_args()

    # Get the shortcuts file path
    real_user = os.getenv('SUDO_USER') or os.getenv('USER') or 'root'
    if real_user == 'root' and os.getenv('SUDO_USER'):
        real_user = os.getenv('SUDO_USER')
        shortcuts_file = os.path.join('/home', real_user, '.shortcuts.json')
    else:
        shortcuts_file = os.path.expanduser('~/.shortcuts.json')

    if args.examples:
        print_usage_examples()
        return

    if args.list:
        list_shortcuts(shortcuts_file)
        return

    # Handle quick shortcut creation with positional arguments
    if args.shortcut_name and args.command:
        app = ShortcutManager()
        app.create_shortcut_script(args.shortcut_name, args.command, args.background)
        return

    # Handle --add with named arguments
    if args.add:
        if not args.name or not args.cmd:
            print("Error: Both --name and --cmd are required when using --add")
            parser.print_help()
            return
        app = ShortcutManager()
        app.create_shortcut_script(args.name, args.cmd, args.background)
        return

    # If no command-line actions specified, launch GUI
    if not any([args.shortcut_name, args.command, args.list, args.add, args.examples]):
        app = ShortcutManager()
        app.mainloop()

if __name__ == "__main__":
    main()
